package com.ivoid.bj;

import android.app.Application;

public class Game extends Application
{

}
