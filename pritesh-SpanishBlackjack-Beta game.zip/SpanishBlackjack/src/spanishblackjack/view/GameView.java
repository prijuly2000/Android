package spanishblackjack.view;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import spanishblackjack.activity.R;
import spanishblackjack.card.Card;
import spanishblackjack.card.FCard;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.media.AudioManager;
import android.media.SoundPool;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class GameView extends View
{
	private SoundPool soundPool;
	private List<Card> playerHand1 = new ArrayList<Card>();
	private List<Card> playerHand2 = new ArrayList<Card>();
	private List<Card> dealerHand = new ArrayList<Card>();
	private List<Card> deck = new ArrayList<Card>();
	// For the hard & soft hand validation
	private boolean soft1 = false, soft2 = false;
	// Number of decks used in the game
	private final int NO_OF_DECKS = 1;
	private final int MAX_RANK = 115;
	private Context myContext;
	private boolean playerDraw;
	private int scaledCardW, scaledCardH, screenW, screenH;
	// Bonus given to the player on special blackjacks (in addition to
	// won-money)
	private int bonus = 0;
	// score for each hand
	private int dealerScore = 0, playerScore1 = 0, playerScore2 = 0;
	// bet placed for the hand & the total balance (after deducting current bet)
	private int bet1 = 0, bet2 = 0, balance = 500;
	private FCard flightCard;
	private int doubleCount = 3;
	private float scale;
	private Paint paint;
	private Bitmap deckCover;
	private boolean split = false, passPress = false, doublePress = false;
	// 0-dealer turn,1-player hand 1 turn,2- player hand 2 turn, (-1) - everyone
	// played,decision needed for winner
	private int turn = 1;
	// Pass button to pass the turn to the next player
	private Bitmap passUpBmp, passDownBmp;
	// Double button to double the current bet
	private Bitmap doubleUpBmp, doubleDownBmp;
	//Variables required for sound effect
	private int dropSound,oppWinSound,playerWinSound,tap;
	private AudioManager audioManager;
	private float volume;
	
	// Number of cards to be drawn by the dealer
	public GameView(Context context)
	{
		super(context);
		myContext = context;
		setBackgroundColor(Color.rgb(0, 135, 0));
		scale = myContext.getResources().getDisplayMetrics().density;
		paint = new Paint();
		paint.setAntiAlias(true);
		paint.setColor(Color.BLACK);
		paint.setStyle(Paint.Style.STROKE);
		paint.setTextAlign(Paint.Align.LEFT);
		paint.setTextSize(scale * 15);
		
		// Add the sounds to the SoundsPool to play it whenever required 
		soundPool=new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
		dropSound=soundPool.load(myContext, R.raw.blip2,1);
		oppWinSound=soundPool.load(myContext, R.raw.evil_laf,1);
		tap=soundPool.load(myContext, R.raw.tap,1);
		playerWinSound=soundPool.load(myContext, R.raw.austin_yeahbaby_converted,1);
		audioManager=(AudioManager)myContext.getSystemService(Context.AUDIO_SERVICE);
		volume=(float)audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
	}

	private void initDeck()
	{
		// Initialize the deck(s)
		int tempId;
		int tempValue;
		int tempBitmapId;
		Bitmap tempBitmap;
		scaledCardW = (int) (screenW / 8);
		scaledCardH = (int) (scaledCardW * 1.28);
		for (int k = 0; k < NO_OF_DECKS; k++)
		{
			for (int i = 0; i < 4; i++)
			{
				tempValue = 2;
				for (int j = 102; j < MAX_RANK; j++)
				{
					// Remove 10 cards from decks
					if (j == 110)
						continue;
					
					tempId = (i * 100) + j;
					tempBitmapId = getResources().getIdentifier(
							"card" + tempId, "drawable",
							myContext.getPackageName());
					tempBitmap = BitmapFactory.decodeResource(getResources(),
							tempBitmapId);
					Card tempCard = new Card(tempId);
					
					// Scale the cards
					Bitmap scaledBitmap = Bitmap.createScaledBitmap(tempBitmap,
							scaledCardW, scaledCardH, false);
					tempCard.setCardBitmap(scaledBitmap);
					tempCard.setCardValue(tempValue);
					deck.add(tempCard);
					if (tempValue != 10 || j == MAX_RANK - 2)
						tempValue++;
				}
			}
		}
		tempBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.card_back);
		deckCover = Bitmap.createScaledBitmap(tempBitmap, scaledCardW,
				scaledCardH, false);
		tempBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.pass_up);
		passUpBmp = Bitmap.createScaledBitmap(tempBitmap, scaledCardW,
				scaledCardH / 4, false);
		tempBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.pass_down);
		passDownBmp = Bitmap.createScaledBitmap(tempBitmap, scaledCardW,
				scaledCardH / 4, false);
		tempBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.double_up);
		doubleUpBmp = Bitmap.createScaledBitmap(tempBitmap, scaledCardW,
				scaledCardH / 4, false);
		tempBitmap = BitmapFactory.decodeResource(getResources(),
				R.drawable.double_down);
		doubleDownBmp = Bitmap.createScaledBitmap(tempBitmap, scaledCardW,
				scaledCardH / 4, false);
	}

	private void newHand()
	{
		// Give feel like the game started again as
		// the balance was not suffice to proceed with the game
		if (balance < 1)
		{
			Toast.makeText(myContext,
					" New Game Started Cause Of Low Balance ",
					Toast.LENGTH_SHORT).show();
			balance = 500;
		}
		
		// For next hand, reset all the parameters before starting new hand
		soft1 = soft2 = false;
		playerScore1 = 0;
		playerScore2 = 0;
		dealerScore = 0;
		turn = 1;
		split = false;
		bet1 = bet2 = 0;
		doubleCount = 3;
		deck.addAll(playerHand1);
		deck.addAll(playerHand2);
		deck.addAll(dealerHand);
		playerHand1.clear();
		playerHand2.clear();
		dealerHand.clear();
		bonus = 0;
		dealCards();
		showBetDialog();
	}

	private void dealCards()
	{
		// Deal cards at the beginning
		for (int i = 0; i < 2; i++)
			Collections.shuffle(deck, new Random());
		for (int i = 0; i < 2; i++)
		{
			playerDraw = true;
			drawCard(playerHand1);
			playerDraw = false;
			drawCard(dealerHand);
		}
		updateScores();
	}

	private void drawCard(List<Card> hand)
	{
		hand.add(hand.size(), deck.get(0));
		
		// If the card drawn by the player is ace then its a soft hand
		if (deck.get(0).getCardValue() == 11 && playerDraw)
		{
			// Make the drawing hand as soft hand
			if (turn == 1)
				soft1 = true;
			else if (turn == 2)
				soft2 = true;
		}
		deck.remove(0);
	}

	@Override
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		System.out.println("onDraw");
		if (bet1 == 0 && bet2 == 0)
			return;
		
		// Display the total balance after betting
		// Display player hand 1 score & the bet played on it
		canvas.drawText("Balance : " + balance, 10,
				screenH - paint.getTextScaleX() - 10, paint);
		if (!playerHand1.isEmpty())
		{
			canvas.drawText("Bet : " + bet1, 10, screenH - scaledCardH - 2
					* paint.getTextSize() - (15 * scale), paint);
			canvas.drawText("Hand 1 Value: " + playerScore1, 100, screenH
					- scaledCardH - 2 * paint.getTextSize() - (15 * scale),
					paint);
		}
		
		// If player hand 2 is present then show player hand 2 score
		// and the bet played on player hand 2
		if(!playerHand2.isEmpty())
		{
			canvas.drawText("Hand 2 Value: " + playerScore2, 100, screenH
					- scaledCardH * 2 - 4 * paint.getTextSize() - (15 * scale),
					paint);
			canvas.drawText("Bet : " + bet2, 10, screenH - scaledCardH * 2 - 4
					* paint.getTextSize() - (15 * scale), paint);
		}
		
		// Pass button used for passing the turn to the next player
		if (!passPress)
		{
			canvas.drawBitmap(passUpBmp, screenW / 2 - passUpBmp.getWidth(),
					screenH - passUpBmp.getHeight() - 5, null);
		}
		else
		{
			canvas.drawBitmap(passDownBmp, screenW / 2 - passUpBmp.getWidth(),
					screenH - passUpBmp.getHeight() - 5, null);
		}
		if (!doublePress)
		{
			canvas.drawBitmap(doubleUpBmp, screenW / 2 + 5, screenH
					- doubleUpBmp.getHeight() - 5, null);
		}
		else
		{
			canvas.drawBitmap(doubleDownBmp, screenW / 2 + 5, screenH
					- doubleUpBmp.getHeight() - 5, null);
		}
		for (int i = 0; i < dealerHand.size(); i++)
		{
			// If not dealer's (computer) turn then keep the second card blind
			// If computer's (computer) turn then show the second card
			if (turn > 0 && i == (dealerHand.size() - 1))
			{
				canvas.drawBitmap(deckCover, i * (scaledCardW + 5),
						paint.getTextSize() + (20 * scale), null);
			}
			else
			{
				canvas.drawBitmap(dealerHand.get(i).getCardBitmap(), i
						* (scaledCardW + 5),
						paint.getTextSize() + (20 * scale), null);
			}
		}
		
		// Simulating Shoe for drawing cards
		canvas.drawBitmap(deckCover,
				(screenW / 2) - (deckCover.getWidth() / 2), (screenH / 2)
						- (deckCover.getHeight() / 2), null);
		for (int i = 0; i < playerHand1.size(); i++)
		{
			canvas.drawBitmap(playerHand1.get(i).getCardBitmap(), i
					* (scaledCardW + 5),
					screenH - scaledCardH - paint.getTextSize() - (20 * scale),
					null);
		}
		
		// If the player's hand is split then display the other hand's cards
		if (split)
		{
			for (int i = 0; i < playerHand2.size(); i++)
			{
				canvas.drawBitmap(playerHand2.get(i).getCardBitmap(), i
						* (scaledCardW + 5), screenH - (scaledCardH * 2)
						- paint.getTextSize() * 3 - (20 * scale), null);
			}
		}
		
		// If the card is in-flight then don't let the player draw a card
		if (flightCard != null)
		{
			flightCard.draw(canvas);
			if (flightCard.hasArrived())
			{
				soundPool.play(dropSound, volume, volume, 1, 0, 1);
				flightCard = null;
				updateScores();
				if (turn != 0)
					checkHands();
			}
		}
		if (turn == 0 && flightCard == null)
			makeDealerPlay();
		invalidate();
	}

	private void checkHands()
	{
		// Check the hands for deciding the winner
		if (playerScore1 > 21 && !playerHand2.isEmpty())
		{
			Toast.makeText(myContext, "You lost 1st hand", Toast.LENGTH_SHORT)
					.show();
			playerScore1 = 0;
			playerHand1.clear();
			bet1 = 0;
			turn = 0;
		}
		else if (split && playerScore2 > 21 && !playerHand1.isEmpty())
		{
			Toast.makeText(myContext, "You lost 2nd hand", Toast.LENGTH_SHORT)
					.show();
			playerHand2.clear();
			playerScore2 = 0;
			bet2 = 0;
			turn = 1;
		}
		else if (playerScore1 > 21 || playerScore2 > 21 || dealerScore > 21
				|| turn == -1)
		{
			endHand();
		}
	}

	private void flyingCard(List<Card> playingHand)
	{
		if (flightCard != null)
			return;
		
		// If Player hand 2 turn then fly the drawn card to the right-bottom
		// corner
		// If Player hand 1 turn then fly the drawn card to the left-bottom
		// corner
		// If computer turn then fly the drawn card to the computer's hand
		Point dest = null;
		if (turn == 2)
		{
			dest = new Point(0, (int) (screenH - (scaledCardH * 2)
					- paint.getTextSize() * 3 - (20 * scale)));
		}
		else if (turn == 1)
		{
			dest = new Point(0, (int) (screenH - scaledCardH
					- paint.getTextSize() - (20 * scale)));
		}
		else if (turn == 0)
		{
			dest = new Point(0, (int) (paint.getTextSize() + (20 * scale)));
		}
		ArrayList<Card> hand = new ArrayList<Card>();
		drawCard(hand);
		Point start = new Point((screenW / 2) - (deckCover.getWidth() / 2),
				(screenH / 2) - (deckCover.getHeight() / 2));
		Card card = hand.get(0);
		flightCard = new FCard(card, start, dest, playingHand);
		return;
	}

	private void endHand()
	{
		if (playerScore1 == 21)
		{
			checkBonus(playerHand1);
		}
		if (playerScore2 == 21)
		{
			checkBonus(playerHand2);
		}
		final Dialog endHandDialog = new Dialog(myContext);
		endHandDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		endHandDialog.setContentView(R.layout.end_hand_dialog);
		Button nxtBtn = (Button) endHandDialog
				.findViewById(R.id.nextHandButton);
		nxtBtn.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				newHand();
				endHandDialog.dismiss();
			}
		});
		
		// Check if player or computer wins
		TextView tv = (TextView) endHandDialog.findViewById(R.id.endHandText);
		if ((dealerScore > 21 || dealerScore < playerScore1
				|| dealerScore < playerScore2 || playerScore1 == 21 || playerScore2 == 21)
				&& turn < 1)
		{
			soundPool.play(playerWinSound, volume, volume, 1, 0, 1);
			if (bonus == 0)
				tv.setText("   Congrats!!You Won  ");
			else
				tv.setText(" Congrats!! You Won With $" + bonus + " bonus ");
			if (playerScore1 > dealerScore || playerScore1 == 21 )
				balance += bet1 * 1.5;
			if (playerScore2 > dealerScore || playerScore2 == 21)
				balance += bet2 * 1.5;
			if (dealerScore > 21)
				balance += (bet1 + bet2) * 1.5;			
		}
		else if (dealerScore == playerScore1 || dealerScore == playerScore2)
		{
			tv.setText("  It's a tie  ");
			balance += bet1;
		}
		else
		{
			soundPool.play(oppWinSound, volume, volume, 1, 0, 1);
			tv.setText("  You lost the hand!!  ");			
		}
		endHandDialog.show();
	}

	private void checkBonus(List<Card> hand)
	{
		// If all same cards then blackjack must be 7's blackjack
		// then check for the bet value
		// If the bet is less than $25 then $1000 bonus
		// If the bet is more than 25 then $5000 bonus
		if (hand.get(0) == hand.get(1) && hand.get(0) == hand.get(2))
		{
			if (bet1 <= 25)
				bonus += 1000;
			else
				bonus += 5000;
		}
		
		// Check for 6,7 & 8 cards blackjack for $2500 bonus
		int tempScore = 0;
		for (int i = 6; i < 9; i++)
		{
			for (Card card : hand)
			{
				if (card.getCardValue() == i)
					tempScore += card.getCardValue();
			}
		}
		if (tempScore == 21)
			bonus += 2500;
		balance += bonus;
	}

	private void updateScores()
	{
		playerScore1 = playerScore2 = dealerScore = 0;
		for (int i = 0; i < playerHand1.size(); i++)
		{
			playerScore1 += playerHand1.get(i).getCardValue();
		}
		for (int i = 0; i < dealerHand.size(); i++)
		{
			dealerScore += dealerHand.get(i).getCardValue();
		}
		for (int i = 0; i < playerHand2.size(); i++)
		{
			playerScore2 += playerHand2.get(i).getCardValue();
		}
		
		// If the player hand 1 score is greater than 21 & the hand is soft
		// then make it a hard hand
		if (soft1 && playerScore1 > 21)
		{
			playerScore1 -= 10;
		}
		
		// If the player hand 1 score is greater than 21 & the hand is soft
		// then make it a hard hand
		if (soft2 && playerScore2 > 21)
		{
			playerScore2 -= 10;
		}
	}
	
	private void showSplitHandDialog()
	{
		// Ask the use if he wants to split the hand into two
		// If the player says YES then splitHand() method will be called
		// which will divide the hand into two & the second hand will be playing
		// first
		final Dialog splitHandDialog = new Dialog(myContext);
		splitHandDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		splitHandDialog.setContentView(R.layout.split_dialog);
		TextView tv = (TextView) splitHandDialog.findViewById(R.id.splitText);
		tv.setText("Put bet between 1 & " + (bet1 < balance ? bet1 : balance)
				+ " & click YES to split");
		Button yesBtn = (Button) splitHandDialog.findViewById(R.id.yesButton);
		yesBtn.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				EditText et = (EditText) splitHandDialog
						.findViewById(R.id.etSplitBet);
				String bet = et.getText().toString();
				if (!bet.equals(""))
				{
					int tempBet = Integer.parseInt(bet);
					if (tempBet <= (bet1 < balance ? bet1 : balance)
							&& tempBet > 1)
					{
						splitHandDialog.dismiss();
						bet2 = tempBet;
						balance -= bet2;
						splitHand();
					}
					else
						et.setText("");
				}
			}
		});
		
		Button noBtn = (Button) splitHandDialog.findViewById(R.id.noButton);
		noBtn.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				splitHandDialog.dismiss();
			}
		});
		splitHandDialog.show();
		split = true;
	}

	private void splitHand()
	{
		// Split the player hand into 2 hands & update the scores of both hands
		playerHand2.add(playerHand1.get(0));
		playerHand1.remove(0);
		turn = 2;
		updateScores();
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh)
	{
		super.onSizeChanged(w, h, oldw, oldh);
		
		// Player has to put the bet before starting the play
		showBetDialog();
		screenW = w;
		screenH = h;
		initDeck();
		dealCards();
	}

	private void showBetDialog()
	{
		// Show bet dialog to put a bet
		final Dialog betDialog = new Dialog(myContext);
		betDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		betDialog.setContentView(R.layout.bet_dialog);
		TextView tv = (TextView) betDialog.findViewById(R.id.tvBet);
		tv.setText("Place the valid bet (MIN : 1 AND MAX : " + balance + ")");
		Button okBtn = (Button) betDialog.findViewById(R.id.okBtnBet);
		okBtn.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				EditText et = (EditText) betDialog.findViewById(R.id.etBet);
				if (!et.getText().toString().equals(""))
					bet1 = Integer.parseInt(et.getText().toString());
				if (bet1 > balance || et.getText().toString().equals("")
						|| bet1 == 0)
				{
					// Invalid bet (bet>balance or bet<1 )
					// Do not dismiss till the valid bet is placed
					et.setText("");
				}
				else
				{
					// Valid bet (1< bet < balance) placed so proceed the play
					balance -= bet1;
					betDialog.dismiss();
					invalidate();					
					
					// Find the rank of the cards by taking MOD of the cardId
					// This will be used to compare the cards based on ranks 
					// for split hand option
					int card1Rank = playerHand1.get(0).getCardId() % 100; 
					int card2Rank = playerHand1.get(1).getCardId() % 100;
					
					// Check if the two cards (dealt initially) have the same rank
					// If Yes then ask the user whether he wants to split the hand
     				if (!split && card1Rank==card2Rank)
						showSplitHandDialog();
				}
			}
		});
		betDialog.show();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		int actionevent = event.getAction();
		int x = (int) event.getX();
		int y = (int) event.getY();
		
		switch (actionevent)
		{
		case MotionEvent.ACTION_DOWN:
			if (x > screenW / 2 - passUpBmp.getWidth() && x < screenW / 2
					&& y > screenH - passUpBmp.getHeight() - 5
					&& y < screenH - 5)
			{
				passPress = true;
				// If current Play hand 2 play then make it Player hand 1 play
				if (turn == 2)
					turn = 1;
				else if (turn == 1)
				{
					// Dealer's or computer's play
					turn = 0;
				}
			}
			if (x > screenW / 2 + 5
					&& x < screenW / 2 + 5 + doubleUpBmp.getWidth()
					&& y > screenH - doubleUpBmp.getHeight() - 5
					&& y < screenH - 5)
			{
				// Check if the double down is valid
				// as player can double 3 times only on each hand 
				if (split)
				{
					Toast.makeText(myContext,
							" Double Not Allowed After Split!! ",
							Toast.LENGTH_SHORT).show();
					return true;
				}
				if (doubleCount == 0)
				{
					Toast.makeText(myContext,
							" MAX double bet limit reached!! ",
							Toast.LENGTH_SHORT).show();
					return true;
				}
				if (balance < bet1)
				{
					Toast.makeText(myContext,
							" Not Enough Balance to Double!! ",
							Toast.LENGTH_SHORT).show();
					return true;
				}
				// Double the bet
				doublePress = true;
				balance -= bet1;
				bet1 += bet1;
				doubleCount--;
				Toast.makeText(
						myContext,
						" Bet Doubled !! You can double " + doubleCount
								+ " times", Toast.LENGTH_SHORT).show();
			}
			break;
			
		case MotionEvent.ACTION_UP:
			// Click on the stock pile for hit
			if (x > (screenW / 2 - deckCover.getWidth() / 2)
					&& x < (screenW / 2 + deckCover.getWidth() / 2)
					&& y > (screenH / 2 - deckCover.getHeight() / 2)
					&& y < (screenH / 2 + deckCover.getHeight() / 2))
			{
				soundPool.play(tap, volume, volume, 1, 0, 1);
				if (turn == 2)
				{
					// Player hand 2 play
					flyingCard(playerHand2);
				}
				else if (turn == 1)
				{
					// Player hand 1 play
					doubleCount = 3;
					flyingCard(playerHand1);
				}
				else if (turn == 0)
				{
					Toast.makeText(myContext, " Wait.. Dealer's Turn ",
							Toast.LENGTH_SHORT).show();
					makeDealerPlay();
				}
			}
			passPress = false;
			doublePress = false;
			break;
			
		case MotionEvent.ACTION_MOVE:
			break;
		}
		invalidate();
		return true;
	}

	private void makeDealerPlay()
	{
		// If the cards are already drawn by the computer then return otherwise
		// draw the card
		if (dealerScore > 16)
		{
			turn = -1;
			checkHands();
			return;
		}
		flyingCard(dealerHand);
	}
}
