package spanishblackjack.activity;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ToggleSoundEffectActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);		
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.sound_effect_layout);
		Button setBtn=(Button) findViewById(R.id.setButton);
		final RadioGroup rGroup=(RadioGroup)findViewById(R.id.radioGroup1);
		int radioButtonID = rGroup.getCheckedRadioButtonId();
		RadioButton selRadioBtn=(RadioButton)findViewById(radioButtonID);
		final String selOption=selRadioBtn.getText().toString();
		final String disableStr = getResources().getString(R.string.disableRadio);
		final AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
		setBtn.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{				
				if(selOption.equals(disableStr))
					am.setStreamMute(AudioManager.STREAM_MUSIC, false);
				else
					am.setStreamMute(AudioManager.STREAM_MUSIC, true);
				finish();									
			}
			
		});
		
		// Display the current sound setting by selecting 
		// the appropriate radio button from the group
		
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		
		return super.onTouchEvent(event);
	}
}
